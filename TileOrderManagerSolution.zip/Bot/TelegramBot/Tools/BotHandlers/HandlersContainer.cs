﻿using Telegram.Bot;
using TelegramBot.Tools.APIServices;
using TelegramBot.Tools.AppErrorHandler;
using TelegramBot.Tools.BotHandlers.Handlers;
using TelegramBot.Tools.BotHandlers.Handlers.Message;

namespace TelegramBot.Tools.BotHandlers
{
    public class HandlersContainer
    {
        public readonly ErrorHandler Errors;
        public readonly MessageHandler Messages;
        public readonly UpdateHandler Updates;

        public HandlersContainer(TelegramBotClient bot, ServicesContainer services)
        {
            Errors = new(bot, services);
            Messages = new(bot, services);
            Updates = new(bot, services);

            BotLogger.SendInfo("Обработчики сообщений, ошибок и запросов инициализированы");
        }
    }
}
