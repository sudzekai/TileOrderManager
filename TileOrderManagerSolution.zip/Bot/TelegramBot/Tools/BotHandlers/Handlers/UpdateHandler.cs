﻿using System.ComponentModel.Design;
using Telegram.Bot;
using TelegramBot.Tools.APIServices;

namespace TelegramBot.Tools.BotHandlers.Handlers
{
    public class UpdateHandler
    {
        private readonly TelegramBotClient _bot;
        private readonly ServicesContainer _services;

        public UpdateHandler(TelegramBotClient bot, ServicesContainer services)
        {
            _bot = bot;
            _services = services;
        }

        public Task OnUpdate(Telegram.Bot.Types.Update update)
        {
            return Task.CompletedTask; 
        }
    }
}
