﻿using BLL.DTO.Objects.User.Special;
using BLL.DTO.Types.Enums;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.ReplyMarkups;
using TelegramBot.Tools.APIServices;
using TelegramBot.Tools.AppErrorHandler;
using TelegramBot.Tools.BotHandlers.Handlers.Messages.Tools;
using TelegramBot.Tools.Extensions;
using TelegramBot.Types;

namespace TelegramBot.Tools.BotHandlers.Handlers.Messages
{
    public class MessageHandler
    {
        private readonly TelegramBotClient _bot;
        private readonly ServicesContainer _services;
        private readonly RegisterHandler _registerHandler;

        public MessageHandler(TelegramBotClient bot, ServicesContainer services)
        {
            _bot = bot;
            _services = services;
            _registerHandler = new(bot, services);
        }

        public async Task OnMessage(Telegram.Bot.Types.Message message, Telegram.Bot.Types.Enums.UpdateType type)
        {
            if (string.IsNullOrWhiteSpace(message.Text)
                || message.From is null)
                return;

            long chatId = message.From.Id;
            string text = message.Text;

            BotLogger.SendLog($"Получено сообщение:\n\"{text}\"\nПользователь: https://t.me/{message.From.Username ?? "-- Username отсутствует"}");

            var user = await _services.Users.GetChatInfoByIdAsync(chatId);

            if (user == null)
            {
                await _services.Users.CreateAsync(new(chatId, message.From.Username ?? "Отсутствует"));
                user = await _services.Users.GetChatInfoByIdAsync(chatId);
            }


            if (user.DialogType.Equals(DialogType.None))
            {
                await HandleCommands(chatId, text);
            }
            else
            {
                await DialogHandler(user, chatId, message);
            }
        }

        private async Task HandleCommands(long chatId, string text)
        {
            if (text.Equals("/start"))
            {
                await HandleStartCommand(chatId);
            }
            else if (MessagesDictionary.GetFor(text) is var answer && answer is not null)
                await _bot.SendMessage(chatId, answer);
        }

        private async Task DialogHandler(BLL.DTO.Objects.User.Special.UserChatInfoDto user, long chatId, Message message)
        {

            if (user.DialogType == DialogType.SimpleRegistering)
            {
                await _registerHandler.HandleSimpleRegistering(message, user);
            }
            else if (user.DialogType.Equals(DialogType.Registering))
            {

            }
            else if (user.DialogType.Equals(DialogType.SimpleOrdering))
            {

            }
            else if (user.DialogType.Equals(DialogType.SimpleOrdering))
            {

            }
        }

        private async Task HandleStartCommand(long chatId)
        {
            var model = MessagesDictionary.GetFor("/start");

            var userInfo = await _services.Users.GetInfoByIdAsync(chatId);

            if (userInfo.FullName != "Не указан")
                model.Markup = new InlineKeyboardMarkup().AddButton("➕Заказать", "start-tiles").AddButton("❓FAQ", "faq").AddButton("🙋О нас", "about").AddNewRow().AddButton("📋Мои данные", "me");

            var userOrders = await _services.Orders.GetAllByUserIdAsync(chatId);

            if (userOrders.Count > 0)
                model.Markup = new InlineKeyboardMarkup().AddButton("➕Заказать", "start-tiles").AddButton("❓FAQ", "faq").AddButton("🙋О нас", "about").AddNewRow().AddButton("📋Мои данные", "me").AddButton("🧰Мои заказы", "start-orders");

            var message = await _bot.SendMessage(chatId, model);

            await _services.Users.UpdateAsync(chatId, new UserChatInfoDto() { LastMessageId = message.Id });
        }

        
    }
}
