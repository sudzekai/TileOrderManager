﻿using BLL.DTO.Objects.User.Special;
using BLL.DTO.Types.Enums;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Types;
using TelegramBot.Types;
using TelegramBot.Tools.Extensions;
using TelegramBot.Tools.APIServices;

namespace TelegramBot.Tools.BotHandlers.Handlers.Messages.Tools
{
    public class RegisterHandler
    {
        TelegramBotClient _bot;
        ServicesContainer _services;

        public RegisterHandler(TelegramBotClient bot, ServicesContainer services)
        {
            _bot = bot;
            _services = services;
        }

        public async Task HandleSimpleRegistering(Message message, UserChatInfoDto user)
        {
            try
            {
                var userInfo = await _services.Users.GetInfoByIdAsync(message.From.Id);

                var msg = message.Text.Split("\n", StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

                if (msg.Length < 2)
                {
                    await _bot.EditMessageText(message.From.Id, user.LastMessageId.Value, MessagesDictionary.GetFor("registration-all-wrong"));
                    return;
                }

                bool flowControl = await IsDataValid(message, user, msg);

                if (!flowControl)
                    return;

                await UpdateUserData(message, user, userInfo, msg);

                await _bot.EditMessageText(message.From.Id, user.LastMessageId.Value, MessagesDictionary.GetFor("registration-all-good"));
            }
            catch (ApiRequestException) { }
            finally
            {
                await _bot.DeleteMessage(message.From.Id, message.Id);
            }
        }

        private async Task UpdateUserData(Message message, UserChatInfoDto user, UserInfoDto userInfo, string[] msg)
        {
            userInfo.FullName = msg[0].Trim();
            userInfo.Phone = msg[1].Trim().NormalizePhone();

            if (msg.Length >= 3)
                userInfo.Email = msg[2].Trim();

            user.DialogType = DialogType.None;

            await _services.Users.UpdateAsync(message.From.Id, user);
            await _services.Users.UpdateAsync(message.From.Id, userInfo);
        }

        private async Task<bool> IsDataValid(Message message, UserChatInfoDto user, string[] msg)
        {
            if (!msg[0].IsValidFullName())
            {
                await _bot.EditMessageText(message.From.Id, user.LastMessageId.Value, MessagesDictionary.GetFor("registration-fullname-wrong"));
                return false;
            }

            if (!msg[1].IsValidPhoneNumber())
            {
                await _bot.EditMessageText(message.From.Id, user.LastMessageId.Value, MessagesDictionary.GetFor("registration-phone-wrong"));
                return false;
            }

            if (msg.Length >= 3 && !msg[2].IsValidEmail())
            {
                await _bot.EditMessageText(message.From.Id, user.LastMessageId.Value, MessagesDictionary.GetFor("registration-email-wrong"));
                return false;
            }

            return true;
        }
    }
}
