﻿using Telegram.Bot.Types.ReplyMarkups;

namespace TelegramBot.Types
{
    public class MessageModel
    {
        public string Command { get; set; } = "";

        public string Text { get; set; } = "";

        public InlineKeyboardMarkup Markup { get; set; } = new();

        public MessageModel() { }

        public MessageModel(string command, string text, InlineKeyboardMarkup markup) 
        {
            Command = command;
            Text = text;
            Markup = markup;
        }
    }
}
