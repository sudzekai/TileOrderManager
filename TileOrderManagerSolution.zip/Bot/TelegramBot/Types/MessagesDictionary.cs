﻿using System.Text.Encodings.Web;
using System.Text.Json;
using Telegram.Bot.Types;
using TelegramBot.Tools.AppErrorHandler;

namespace TelegramBot.Types
{
    public static class MessagesDictionary
    {
        public static List<MessageModel> Messages { get; private set; } = [];

        private static JsonSerializerOptions _jsonOptions;

        private static bool _isInitialized = false;

        public static async Task Add(MessageModel message)
        {
            if (_isInitialized)
            {
                Messages.Add(message);

                await File.WriteAllTextAsync("Data/messages.json", JsonSerializer.Serialize(Messages, options: _jsonOptions));
                BotLogger.SendLog("Сообщение добавлено");
                return;
            }
            BotLogger.SendLog($"Словарь не инициализирован");
        }

        public static async Task Edit(MessageModel message)
        {
            if (_isInitialized)
            {
                var msg = Messages.Find(x => x.Command == message.Command);

                msg = message;

                await File.WriteAllTextAsync("Data/messages.json", JsonSerializer.Serialize(Messages, options: _jsonOptions));
                BotLogger.SendLog("Сообщение добавлено");
                return;
            }
            BotLogger.SendLog($"Словарь не инициализирован");
        }

        public static void Initialize()
        {
            _jsonOptions = new JsonSerializerOptions()
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            };

            if (!Directory.Exists("Data"))
                Directory.CreateDirectory("Data");

            if (!File.Exists("Data/messages.json"))
                File.Create("Data/messages.json");

            try
            {
                var jsonString = File.ReadAllText("Data/messages.json");
                Messages = JsonSerializer.Deserialize<List<MessageModel>>(jsonString) ?? throw new Exception("Ошибка сериализации json с сообщениями");
            }
            catch (Exception ex)
            {
                BotLogger.HandleException(ex);
            }
            _isInitialized = true;
        }

        public static MessageModel GetFor(string command)
        {
            return Messages.FirstOrDefault(x => x.Command == command);
        } 
    }
}
